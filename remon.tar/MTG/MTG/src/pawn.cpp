#include "pawn.hpp"
Pawn::Pawn(int x, int y, int id): x(x), y(y), id(id), HomeX(x), HomeY(y) {}